<?php
require_once '../../config.php';
//Variable
$id = isset($_POST['user_id']) ? $_POST['user_id'] : '';
$name = isset($_POST['name']) ? $_POST['name'] : '';

if (empty($id) && empty($name)) {
	$arr = array (
	"ok" => false,
	"code" => 1,
	"text" => "You not have permission"
	);
	echo json_encode($arr, JSON_PRETTY_PRINT);
	exit;
}

$databaseManager = new DatabaseManager();
$databaseManager->changeName($id, $name);

//close request
$databaseManager->close();
exit;
?>