<?php
require_once '../../config.php';
// Variables
$id = isset($_POST['user_id']) ? $_POST['user_id'] : '';
$gender = isset($_POST['gender']) ? $_POST['gender'] : '';

if (empty($id) || empty($gender)) {
    $response = array(
        "ok" => false,
        "code" => 1,
        "text" => "Missing user ID or gender"
    );
    echo json_encode($response, JSON_PRETTY_PRINT);
    exit;
}

$databaseManager = new DatabaseManager();
$databaseManager->changeUserGender($id, $gender);

//close request
$databaseManager->close();
exit;
?>
