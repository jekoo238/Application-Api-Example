<?php
require_once '../../config.php';
//Variable
$id = isset($_POST['user_id']) ? $_POST['user_id'] : '';
$username = isset($_POST['username']) ? $_POST['username'] : '';

if (empty($id) && empty($username)) {
    $arr = array (
        "ok" => false,
        "code" => 1,
        "text" => "You not have permission"
	);
	echo json_encode($arr, JSON_PRETTY_PRINT);
    exit;
}

$databaseManager = new DatabaseManager();
$databaseManager->updateUserName($id, $username);

//close request
$databaseManager->close();
exit;
?>