<?php
require_once '../../config.php';

$id = isset($_POST['user_id']) ? $_POST['user_id'] : '';
$about = isset($_POST['bio']) ? $_POST['bio'] : '';

if (empty($id) || empty($about)) {
    $response = array(
        "ok" => false,
        "code" => 1,
        "text" => "You do not have permission"
    );
    echo json_encode($response, JSON_PRETTY_PRINT);
    exit;
}

$databaseManager = new DatabaseManager();
$databaseManager->changeUserBio($id, $about);

//close request
$databaseManager->close();
exit;
?>