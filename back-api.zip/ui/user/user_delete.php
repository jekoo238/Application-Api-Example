<?php
require_once '../../config.php';

//Check id
$id = isset($_POST['user_id']) ? $_POST['user_id'] : '';
if (empty($id)) {
    $response = array(
        "ok" => false,
        "text" => "id empty!",
        "code" => 1
    );
    echo json_encode($response, JSON_PRETTY_PRINT);
    //close request
    exit;
}

$databaseManager = new DatabaseManager();

// Create an array to store the response
$response = array();

// Call the function to delete user with ID
$response['photo_file'] = deletePhotoFile($databaseManager->conn(), $id);
$response['user'] = deleteUser($databaseManager->conn(), $id);

// Encode the response array as JSON
echo json_encode($response, JSON_PRETTY_PRINT);

function deleteUser($conn, $userId) {
    // Delete user from User table
    //Note: tabel UserData secara otomatis terhapus karena saling terhubung menggunakan rules bawaan mysql FOREIGN KEY (id) REFERENCES `User` (id) ON DELETE CASCADE
    $deleteUserQuery = "DELETE FROM `Users` WHERE `id` = $userId";
    if (mysqli_query($conn, $deleteUserQuery)) {
        return array(
            "ok" => true,
            "text" => "User deleted successfully"
        );
    } else {
        return array(
            "ok" => false,
            "text" => "Error deleting user: " . mysqli_error($conn)
        );
    }
}

function deletePhotoFile($conn, $id) {
    // Delete user's profile photo file from UserData table
    $result = mysqli_query($conn, "SELECT photo FROM `UserDetails` WHERE `id` = $id");
    if ($result && $row = mysqli_fetch_assoc($result)) {
        $imageUrl = $row['photo'];
        $file_path = $_SERVER['DOCUMENT_ROOT'] . parse_url($imageUrl, PHP_URL_PATH);
        if (file_exists($file_path)) {
            if (unlink($file_path)) {
                return array(
                    "ok" => true,
                    "text" => "Profile photo file deleted successfully"
                );
            } else {
                return array(
                    "ok" => false,
                    "text" => "Error deleting profile photo file"
                );
            }
        }
    }

    return array(
        "ok" => false,
        "text" => "Profile photo file not found"
    );
}
?>
