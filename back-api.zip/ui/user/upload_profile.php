<?php
require_once '../../config.php';
$id = isset($_POST['user_id']) ? $_POST['user_id'] : '';
if (empty($id)) {
    //close request
	exit;
}
$assets_path = $_SERVER['DOCUMENT_ROOT'] . "/back-api/assets/profile/";
$assets_url = "https://" . $_SERVER['SERVER_NAME'] . "/back-api/assets/profile/";
//Create Folder
if (!file_exists($assets_path)) {
	mkdir($assets_path, 0777, true);
}

$databaseManager = new DatabaseManager();

//StartUpload
if (is_uploaded_file($_FILES['msk']['tmp_name'])) {
	deleteImageBefore($databaseManager->conn(), $id, $assets_path);
	//Variable
	$tmp_name = $_FILES['msk']['tmp_name'];
	$file_name = $_FILES['msk']['name'];
	$file_type = end(explode('.', $file_name));
	//Where this file exist
	$currentTime = time();
	$timePart = substr($currentTime, -8);
	
	$shortUrlToken = substr(uniqid(), 0, 8);
	$file_name = $id . $timePart . $shortUrlToken . "." . $file_type;
	//Upload to server
	$dir_file = $assets_path . $id . "/";
	if (!file_exists($dir_file)) {
		mkdir($dir_file);
	}
	move_uploaded_file($tmp_name, $dir_file . $file_name);
	//Update user info;
	chengeUserPhoto($databaseManager->conn(), $id, $assets_url, $file_type, $file_name);
	//close request
    $databaseManager->close();
    exit;
}

function deleteImageBefore($conn, $id, $assets_path) {
	//Mengahpus profil yang sebelumnya
	$result = mysqli_query($conn, "SELECT photo FROM UserDetails WHERE id = $id");
	if ($result && $row = mysqli_fetch_assoc($result)) {
		$file_path = $assets_path . $id . "/" . $row['photo'];
		if (file_exists($file_path)) {
			if (unlink($file_path)) {
				//berhasil di hapus
			} else {
				//gagal menghapus file
			}
		} else {
			//File tidak ditemukan
		}
	}
}

function chengeUserPhoto($conn, $id, $assets_url, $file_type, $file_name) {
	$file_type = mysqli_real_escape_string($conn, $file_type);
	$file_name = mysqli_real_escape_string($conn, $file_name);
	
	$data = "UPDATE UserDetails SET photo = '$file_name' WHERE id = '$id';";
	if (mysqli_query($conn, $data)) {
		$url = $assets_url . $id . "/" . $file_name;
		//Succes Response;
		$response = array (
		"ok" => true,
		"text" => "sucess",
		"code" => 0,
		"file_type" => $file_type,
		"url" => $url
		);
	} else {
		//Bad Response;
		$response = array (
		"ok" => false,
		"text" => "failed update MYSQL",
		"code" => 1,
		"file_type" => "not found",
		"url" => "failed"
		);
	}
	echo json_encode($response, JSON_PRETTY_PRINT);
}
?>
