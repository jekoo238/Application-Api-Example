<?php
$to = "tabletmito.t35@gmail.com";
$from = "ManggaToon";
$verificationId = "ABC123";

if (empty($to)) {
    echo "error";
} else {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);

    // Header email dengan tipe konten HTML
    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
    $headers .= "From: " . $from;

    // Pesan email dengan instruksi untuk menyalin ID verifikasi
    $email_body = '
    <html>
    <head>
        <title>Selamat datang di MegaToon</title>
        <!-- Tambahkan link ke Bootstrap CSS di sini jika diperlukan -->
    </head>
    <body>
        <div class="container">
            <div class="jumbotron">
                <h1>Selamat datang di MegaToon</h1>
                <p>Salin ID verifikasi ini: <strong>' . $verificationId . '</strong></p>
                <p>Silakan salin ID verifikasi di atas dan gunakan untuk masuk ke akun anda.</p>
            </div>
        </div>
    </body>
    </html>
    ';

    if (mail($to, "Subjek Email Anda", $email_body, $headers)) {
        echo 'true';
    } else {
        echo 'false';
    }
}
?>