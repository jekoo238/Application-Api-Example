<?php
require_once '../../config.php';
$databaseManager = new DatabaseManager();
// Query untuk mendapatkan semua entri dari tabel User
$query = "SELECT * FROM Users";
$result = $databaseManager->conn()->query($query);

// Array kosong untuk menyimpan data pengguna
$userList = array();

// Memeriksa hasil query
if ($result->num_rows > 0) {
    // Mendapatkan setiap baris data dari hasil query
    while ($row = $result->fetch_assoc()) {
        // Menambahkan baris data ke array user
        $userList[] = $row;
    }
}

// Mengonversi array menjadi format JSON
$userJson = json_encode($userList);

// Mengirimkan hasil JSON sebagai respons
echo $userJson;

//close request
$databaseManager->close();
exit;
?>
