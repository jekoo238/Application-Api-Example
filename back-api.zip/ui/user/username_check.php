<?php
require_once '../../config.php';
//Variable
$id = isset($_POST['user_id']) ? $_POST['user_id'] : '';
$username = isset($_POST['username']) ? $_POST['username'] : '';
$constructor = isset($_POST['constructor']) ? $_POST['constructor'] : '';

if (empty($id) && empty($username) && empty($constructor)) {
    $arr = array (
        "ok" => false,
        "code" => 1,
        "text" => "You not have permission"
	);
	echo json_encode($arr, JSON_PRETTY_PRINT);
	//close request
    exit;
}

$databaseManager = new DatabaseManager();
$databaseManager->checkUserNameIsAvaible($username);

//close request
$databaseManager->close();
exit;
?>