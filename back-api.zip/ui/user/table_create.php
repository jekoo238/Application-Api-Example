<?php
require_once '../../config.php';

$databaseManager = new DatabaseManager();
$databaseManager->createAllTable();

//close request
$databaseManager->close();
exit;
?>