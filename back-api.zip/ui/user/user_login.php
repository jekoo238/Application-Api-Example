<?php
require_once '../../config.php';

// Mengambil nilai dari POST
$email = isset($_POST['email']) ? $_POST['email'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$mention_id = isset($_POST['mention_id']) ? $_POST['mention_id'] : '';
$lang_code = isset($_POST['lang_code']) ? $_POST['lang_code'] : 'en';
if (empty($email) || empty($password)) {
    $response = array(
        "ok" => false,
        "text" => "Email or password empty!",
        "code" => 1
    );
    echo json_encode($response, JSON_PRETTY_PRINT);
    exit;
}

$databaseManager = new DatabaseManager();

// Melakukan sanitasi pada variabel email dan password
$email = filter_var($email, FILTER_SANITIZE_EMAIL);
$password = filter_var($password, FILTER_SANITIZE_STRING);

# SQL Request
$req = mysqli_query($databaseManager->conn(), "SELECT * FROM Users WHERE email='$email' LIMIT 1;");
if (mysqli_num_rows($req) > 0) {
	//if user already account
	$name = getNameFromEmail($email);
	
	$name = mysqli_real_escape_string($databaseManager->conn(), $name);
	$lang_code = mysqli_real_escape_string($databaseManager->conn(), $lang_code);
	
	login($databaseManager->conn(), $email, $password, $mention_id, $name, $lang_code, false);
} else {
	// if user not found
	$username = getUsernameFromEmail($email);
	$date = date('Y-m-d H:i:s');
	
	// Melakukan sanitasi pada variabel
	$email = mysqli_real_escape_string($databaseManager->conn(), $email);
    $password = mysqli_real_escape_string($databaseManager->conn(), $password);
	$username = mysqli_real_escape_string($databaseManager->conn(), $username);
	
	// Hash enkripsi password
	$passwordHash = password_hash($password, PASSWORD_DEFAULT);
	
	$req = "INSERT INTO Users (
        email,
        password,
        username,
        created_date,
        updated_date
    ) VALUES (
        '$email',
        '$passwordHash',
        '$username',
        '$date',
        '$date'
    );";
    if (mysqli_query($databaseManager->conn(), $req)) {
        //user already account
        login($databaseManager->conn(), $email, $password, $mention_id, $username, $lang_code, true);
	}
}
// close request
$databaseManager->close();
exit;

// function
function getUsernameFromEmail($email) {
    $username = str_replace("@gmail.com", "", $email);
    return $username;
}

function getNameFromEmail($username) {
    $name = getUsernameFromEmail($username);
    return str_replace("@", "", $name);
}

function login($conn, $email, $password, $mention_id, $name, $lang_code, $register) {
    $data = mysqli_query($conn, "SELECT * FROM Users WHERE email='$email' LIMIT 1;");
    if (mysqli_num_rows($data) > 0) {
        $row = mysqli_fetch_assoc($data);
        if (password_verify($password, $row['password'])) {
            // Password cocok, lanjutkan proses login
            // Dapatkan lebih banyak data pengguna
            getMoreUserData($conn, $row, $mention_id, $name, $lang_code, $register);
        } else {
            $arr = array(
                "ok" => false,
                "text" => "Email or password wrong!",
                "code" => 1
            );
            echo json_encode($arr, JSON_PRETTY_PRINT);
        }
    } else {
        $arr = array(
            "ok" => false,
            "text" => "Email or password wrong!",
            "code" => 1
        );
        echo json_encode($arr, JSON_PRETTY_PRINT);
    }
}

function getMoreUserData($conn, $rows, $mention_id, $name, $lang_code, $register) {
    $id = (int)$rows["id"];
    if ($register) {
        $type = '0'; // Set the value of $type according to your requirements
        $req = "INSERT INTO UserDetails(
            id,
            type,
            name,
            gender,
            lang_code,
            mention_id,
            last_accessed,
            about,
            photo
        ) VALUES (
            '$id',
            '$type',
            '$name',
            'Other',
            '$lang_code',
            '$mention_id',
            NOW(),
            'Hello world',
            'null'
        );";

        if (mysqli_query($conn, $req)) {
            getMoreUserData($conn, $rows, $mention_id, $name, $lang_code, false);
        }
    } else {
        $data = mysqli_query($conn, "SELECT * FROM UserDetails WHERE id=$id LIMIT 1;");
        $row = array(
            "ok" => true,
            "afterSignup" => true
        );
        while ($r = mysqli_fetch_assoc($data)) {
            $r['photo'] = "https://" . $_SERVER['SERVER_NAME'] . "/back-api/assets/profile/". $r['id'] . "/" . $r['photo'];
            $row = array_merge($row, $r);
        }
        echo json_encode(array_merge($row, $rows), JSON_PRETTY_PRINT);
    }
}
?>
