<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once '../../config.php';

// Check if the search query is provided
$searchQuery = isset($_POST['query']) ? $_POST['query'] : '';

if (empty($searchQuery)) {
    $response = array(
        "ok" => false,
        "text" => "Search query is empty!",
        "code" => 1
    );
    echo json_encode($response, JSON_PRETTY_PRINT);
    //close request
    exit;
}

$databaseManager = new DatabaseManager();

// Call the function to search for users
$searchResultsUser = searchUsers($databaseManager->conn(), $searchQuery);
$searchResultsUserData = searchUseData($databaseManager->conn(), $searchQuery);

// Combine the search results from both tables
$searchResults = array_merge($searchResultsUser, $searchResultsUserData);

// Sort the search results based on similarity score
usort($searchResults, function($a, $b) use ($searchQuery) {
    $scoreA = calculateScore($a, $searchQuery);
    $scoreB = calculateScore($b, $searchQuery);
    return $scoreB - $scoreA;
});

// Encode the search results as JSON
echo json_encode($searchResults, JSON_PRETTY_PRINT);

// close request
$databaseManager->close();
exit;

//function
function searchUsers($conn, $searchQuery) {
    // Sanitize the search query to prevent SQL injection
    $searchQuery = mysqli_real_escape_string($conn, $searchQuery);

    // Search for users based on the provided search query
    $searchQuery = '%' . $searchQuery . '%';
    $searchUsersQuery = "SELECT * FROM `Users` WHERE `id` LIKE '$searchQuery' OR `username` LIKE '$searchQuery''";
    $result = mysqli_query($conn, $searchUsersQuery);

    // Prepare the search results array
    $searchResults = array();

    // Check if any results were found
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            // Add each user to the search results array
            $user = array(
                "id" => $row['id'],
                "type" => $row['type'],
                "email" => $row['email'],
                "password" => $row['password'],
                "username" => $row['username'],
                "lang_code" => $row['lang_code'],
                "created_date" => $row['created_date'],
                "updated_date" => $row['updated_date'],
                "name" => $row['name']
            );
            $searchResults[] = $user;
        }
    }

    return $searchResults;
}

function searchUseData($conn, $searchQuery) {
    // Sanitize the search query to prevent SQL injection
    $searchQuery = mysqli_real_escape_string($conn, $searchQuery);

    // Search for users based on the provided search query
    $searchQuery = '%' . $searchQuery . '%';
    $searchUsersQuery = "SELECT * FROM `UserDetails` WHERE `name` LIKE '$searchQuery' OR `about` LIKE '$searchQuery'";
    $result = mysqli_query($conn, $searchUsersQuery);

    // Prepare the search results array
    $searchResults = array();

    // Check if any results were found
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            // Add each user to the search results array
            $user = array(
                "id" => $row['id'],
                "json" => $row['json'],
                "mention_id" => $row['mention_id'],
                "photo" => $row['photo'],
                "about" => $row['about']
            );
            $searchResults[] = $user;
        }
    }

    return $searchResults;
}

function calculateScore($user, $query) {
    $score = 0;

    // Calculate the score based on ID, username, name, and about similarity
    if (strpos($user['id'], $query) !== false) {
        $score += 4;
    }
    if (strpos($user['username'], $query) !== false) {
        $score += 3;
    }
    if (strpos($user['name'], $query) !== false) {
        $score += 2;
    }
    if (isset($user['about']) && strpos($user['about'], $query) !== false) {
        $score += 1;
    }

    return $score;
}
?>
