<?php
require_once '../../config.php';

$databaseManager = new DatabaseManager();
$databaseManager->clearAllTable();

//close request
$databaseManager->close();
exit;
?>