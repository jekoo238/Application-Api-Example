<?php
$data = array(
    "server_status" => true,
    "title" => "New Update Available",
    "version" => "2.1",
    "version_can_skip" => "2.1",
    "can_not_skip" => false,
    "url" => "https://google.com",
    "text" => "**New update available**\n- **Bug fixed**\n- **New UI app**\n Update **UI** smooth",
    "document" => array(
        "file_name" => "Application",
        "size" => "4000000",
        "date" => 1689478502507
    ),
    "textList" => array(
        array(
            "title" => "- Bug fixed",
            "subtitle" => "Optimalisasi kinerja aplikasi"
        ),
        array(
            "title" => "- New app UI design",
            "subtitle" => "Optimalisasi UI design pada **Profile** dan **Halaman utama**"
        ),
        array(
            "title" => "- Bug fixed",
            "subtitle" => "Optimalisasi kinerja aplikasi"
        ),
        array(
            "title" => "- New app UI design",
            "subtitle" => "Optimalisasi UI design pada **Profile** dan **Halaman utama**"
        ),
        array(
            "title" => "- Bug fixed",
            "subtitle" => "Optimalisasi kinerja aplikasi"
        ),
        array(
            "title" => "- New app UI design",
            "subtitle" => "Optimalisasi UI design pada **Profile** dan **Halaman utama**"
        ),
        array(
            "title" => "- Bug fixed",
            "subtitle" => "Optimalisasi kinerja aplikasi"
        ),
        array(
            "title" => "- New app UI design",
            "subtitle" => "Optimalisasi UI design pada **Profile** dan **Halaman utama**"
        ),
        array(
            "title" => "- Bug fixed",
            "subtitle" => "Optimalisasi kinerja aplikasi"
        ),
        array(
            "title" => "- New app UI design",
            "subtitle" => "Optimalisasi UI design pada **Profile** dan **Halaman utama**"
        ),
        array(
            "title" => "- Bug fixed",
            "subtitle" => "Optimalisasi kinerja aplikasi"
        ),
        array(
            "title" => "- New app UI design",
            "subtitle" => "Optimalisasi UI design pada **Profile** dan **Halaman utama**"
        )
    )
);

echo json_encode($data, JSON_PRETTY_PRINT);
?>
